// SPDX-License-Identifier: BUSL-1.1

pragma solidity ^0.8.0;

import "@openzeppelin/contracts/security/ReentrancyGuard.sol";
import "./OrderHandler.sol";
import "./BaseOrderHandler.sol";
import "../error/ErrorUtils.sol";
import "./IProxyOrderHandler.sol";
import "../order/OrderUtils.sol";
import "../order/ExecuteOrderUtils.sol";
import "../multichain/MultichainVault.sol";

// @title ProxyOrderHandler
// @dev Contract to handle creation, execution and cancellation of orders
contract ProxyOrderHandler is IProxyOrderHandler, BaseOrderHandler, ReentrancyGuard {
    using SafeCast for uint256;
    using Order for Order.Props;
    using Array for uint256[];

    IOrderExecutor public immutable increaseOrderExecutor;
    IOrderExecutor public immutable decreaseOrderExecutor;
    IOrderExecutor public immutable swapOrderExecutor;
    OrderHandler public immutable orderHandler;

    constructor(
        RoleStore _roleStore,
        DataStore _dataStore,
        EventEmitter _eventEmitter,
        IOracle _oracle,
        MultichainVault _multichainVault,
        OrderVault _orderVault,
        ISwapHandler _swapHandler,
        IReferralStorage _referralStorage,
        IOrderExecutor _increaseOrderExecutor,
        IOrderExecutor _decreaseOrderExecutor,
        IOrderExecutor _swapOrderExecutor
    )
        BaseOrderHandler(
            _roleStore,
            _dataStore,
            _eventEmitter,
            _oracle,
            _multichainVault,
            _orderVault,
            _swapHandler,
            _referralStorage
        )
    {
        increaseOrderExecutor = _increaseOrderExecutor;
        decreaseOrderExecutor = _decreaseOrderExecutor;
        swapOrderExecutor = _swapOrderExecutor;
    }

    // @dev creates a proxy order in the order store
    function proxyCreateOrder(
        address account,
        uint256 srcChainId,
        IBaseOrderUtils.CreateOrderParams calldata params
    ) external override globalNonReentrant onlyController returns (bytes32) {
        FeatureUtils.validateFeature(
            dataStore,
            Keys.createOrderFeatureDisabledKey(address(this), uint256(params.orderType))
        );
        validateDataListLength(params.dataList.length);

        (bytes32 key, ) = OrderUtils.proxyCreateOrder(
            true,
            dataStore,
            eventEmitter,
            orderVault,
            referralStorage,
            account,
            srcChainId,
            params
        );
        return key;
    }

    struct UpdateOrderCache {
        address wnt;
        uint256 receivedWnt;
        uint256 estimatedGasLimit;
        uint256 oraclePriceCount;
    }

    /**
     * @dev Updates the given order with the specified size delta, acceptable price, and trigger price.
     * The `updateOrder()` feature must be enabled for the given order type. The caller must be the owner
     * of the order, and the order must not be a market order. The size delta, trigger price, and
     * acceptable price are updated on the order, and the order is unfrozen. Any additional WNT that is
     * transferred to the contract is added to the order's execution fee. The updated order is then saved
     * in the order store, and an `OrderUpdated` event is emitted.
     *
     * A user may be able to observe exchange prices and prevent order execution by updating the order's
     * trigger price or acceptable price
     *
     * The main front-running concern is if a user knows whether the price is going to move up or down
     * then positions accordingly, e.g. if price is going to move up then the user opens a long position
     *
     * With updating of orders, a user may know that price could be lower and delays the execution of an
     * order by updating it, this should not be a significant front-running concern since it is similar
     * to observing prices then creating a market order as price is decreasing
     *
     * @param key The unique ID of the order to be updated
     * @param sizeDeltaUsd The new size delta for the order
     * @param acceptablePrice The new acceptable price for the order
     * @param triggerPrice The new trigger price for the order
     */
    function proxyUpdateOrder(
        bytes32 key,
        uint256 sizeDeltaUsd,
        uint256 acceptablePrice,
        uint256 triggerPrice,
        uint256 minOutputAmount,
        uint256 validFromTime,
        bool autoCancel,
        Order.Props memory order
    ) external override globalNonReentrant onlyController {
        FeatureUtils.validateFeature(
            dataStore,
            Keys.updateOrderFeatureDisabledKey(address(this), uint256(order.orderType()))
        );

        if (Order.isMarketOrder(order.orderType())) {
            revert Errors.OrderNotUpdatable(uint256(order.orderType()));
        }

        // this could happen if the order was created in new contracts that support new order types
        // but the order is being updated in old contracts
        if (!Order.isSupportedOrder(order.orderType())) {
            revert Errors.UnsupportedOrderType(uint256(order.orderType()));
        }

        if (order.autoCancel() != autoCancel) {
            OrderUtils.updateAutoCancelList(dataStore, key, order, autoCancel);
            OrderUtils.validateTotalCallbackGasLimitForAutoCancelOrders(dataStore, order);
        }
        order.setAutoCancel(autoCancel);

        order.setSizeDeltaUsd(sizeDeltaUsd);
        order.setTriggerPrice(triggerPrice);
        order.setAcceptablePrice(acceptablePrice);
        order.setMinOutputAmount(minOutputAmount);
        order.setValidFromTime(validFromTime);
        order.setIsFrozen(false);
        order.setExecutionFee(0);

        order.touch();

        BaseOrderUtils.validateNonEmptyOrder(order);

        OrderStoreUtils.set(dataStore, key, order);

        OrderEventUtils.emitOrderUpdated(eventEmitter, key, order);
    }

    /**
     * @dev Cancels the given order. The `cancelOrder()` feature must be enabled for the given order
     * type. The caller must be the owner of the order. The order is cancelled by calling the `cancelOrder()`
     * function in the `OrderUtils` contract. This function also records the starting gas amount and the
     * reason for cancellation, which is passed to the `cancelOrder()` function.
     *
     * @param key The unique ID of the order to be cancelled
     */
    function proxyCancelOrder(bytes32 key) external override globalNonReentrant onlyController {
        uint256 startingGas = gasleft();

        DataStore _dataStore = dataStore;
        Order.Props memory order = OrderStoreUtils.get(_dataStore, key);

        FeatureUtils.validateFeature(
            _dataStore,
            Keys.cancelOrderFeatureDisabledKey(address(this), uint256(order.orderType()))
        );

        if (Order.isMarketOrder(order.orderType())) {
            validateRequestCancellation(order.updatedAtTime(), "Order");
        }

        // note that order.account would receive the execution fee for the
        // gas cost of cancelling the order
        // the cancellationReceiver would receive the excess executionf fee refund
        OrderUtils.cancelOrder(
            OrderUtils.CancelOrderParams(
                dataStore,
                eventEmitter,
                multichainVault,
                orderVault,
                key,
                order.account(),
                startingGas,
                true, // isExternalCall
                false, // isAutoCancel
                Keys.USER_INITIATED_CANCEL,
                ""
            )
        );
    }

    function proxyExecuteOrder(
        bytes32 key,
        address keeper,
        OracleUtils.SetPricesParams calldata oracleParams
    ) external globalNonReentrant onlyController withOraclePrices(oracleParams) {
        uint256 startingGas = gasleft();

        Order.Props memory order = OrderStoreUtils.get(dataStore, key);
        uint256 estimatedGasLimit = GasUtils.estimateExecuteOrderGasLimit(dataStore, order);
        GasUtils.validateExecutionGas(dataStore, startingGas, estimatedGasLimit);

        uint256 executionGas = GasUtils.getExecutionGas(dataStore, startingGas);

        try
            this.doExecuteOrder{ gas: executionGas }(
                true,
                key,
                order,
                keeper,
                false // isSimulation
            )
        {} catch (bytes memory reasonBytes) {
            _handleOrderError(key, keeper, startingGas, reasonBytes);
        }
    }

    function proxyCreateAndExecuteOrder(
        address account,
        address keeper,
        uint256 srcChainId,
        IBaseOrderUtils.CreateOrderParams calldata params,
        OracleUtils.SetPricesParams calldata oracleParams
    ) external globalNonReentrant onlyController withOraclePricesForAtomicAction(oracleParams) {
        FeatureUtils.validateFeature(
            dataStore,
            Keys.createOrderFeatureDisabledKey(address(this), uint256(params.orderType))
        );
        validateDataListLength(params.dataList.length);

        (bytes32 key, Order.Props memory order) = OrderUtils.proxyCreateOrder(
            false,
            dataStore,
            eventEmitter,
            orderVault,
            referralStorage,
            account,
            srcChainId,
            params
        );

        uint256 startingGas = gasleft();

        uint256 estimatedGasLimit = GasUtils.estimateExecuteOrderGasLimit(dataStore, order);
        GasUtils.validateExecutionGas(dataStore, startingGas, estimatedGasLimit);

        uint256 executionGas = GasUtils.getExecutionGas(dataStore, startingGas);

        this.doExecuteOrder{ gas: executionGas }(
            false,
            key,
            order,
            keeper,
            false // isSimulation
        );
    }

    function doExecuteOrder(
        bool removeOrder,
        bytes32 key,
        Order.Props memory order,
        address keeper,
        bool isSimulation
    ) external nonReentrant onlySelfOrController {
        uint256 startingGas = gasleft();

        BaseOrderUtils.ExecuteOrderParams memory params = _getExecuteOrderParams(
            key,
            order,
            keeper,
            startingGas,
            Order.SecondaryOrderType.None
        );
        // limit swaps require frozen order keeper for execution since on creation it can fail due to output amount
        // which would automatically cause the order to be frozen
        // limit increase and limit / trigger decrease orders may fail due to output amount as well and become frozen
        // but only if their acceptablePrice is reached
        if (!isSimulation && (params.order.isFrozen() || params.order.orderType() == Order.OrderType.LimitSwap)) {
            _validateFrozenOrderKeeper(keeper);
        }

        FeatureUtils.validateFeature(
            params.contracts.dataStore,
            Keys.executeOrderFeatureDisabledKey(address(this), uint256(params.order.orderType()))
        );

        ExecuteOrderUtils.executeOrder(removeOrder, getOrderExecutor(params.order.orderType()), params);
    }

    function getOrderExecutor(Order.OrderType orderType) internal view returns (IOrderExecutor) {
        if (Order.isIncreaseOrder(orderType)) {
            return increaseOrderExecutor;
        }

        if (Order.isDecreaseOrder(orderType)) {
            return decreaseOrderExecutor;
        }

        if (Order.isSwapOrder(orderType)) {
            return swapOrderExecutor;
        }

        revert Errors.UnsupportedOrderType(uint256(orderType));
    }

    // @dev handle a caught order error
    // @param key the order's key
    // @param startingGas the starting gas
    // @param reason the error reason
    // @param reasonKey the hash or the error reason
    function _handleOrderError(bytes32 key, address keeper, uint256 startingGas, bytes memory reasonBytes) internal {
        GasUtils.validateExecutionErrorGas(dataStore, reasonBytes);

        bytes4 errorSelector = ErrorUtils.getErrorSelectorFromData(reasonBytes);

        validateNonKeeperError(errorSelector, reasonBytes);

        Order.Props memory order = OrderStoreUtils.get(dataStore, key);
        bool isMarketOrder = Order.isMarketOrder(order.orderType());

        if (
            // if the order is already frozen, revert with the custom error to provide more information
            // on why the order cannot be executed
            order.isFrozen() ||
            // for market orders, the EmptyPosition error should still lead to the
            // order being cancelled
            // for limit, trigger orders, the EmptyPosition error should lead to the transaction
            // being reverted instead
            // if the position is created or increased later, the oracle prices used to fulfill the order
            // must be after the position was last increased, this is validated in DecreaseOrderUtils
            (!isMarketOrder && errorSelector == Errors.EmptyPosition.selector) ||
            errorSelector == Errors.EmptyOrder.selector ||
            // if the order execution feature is disabled, it may be possible
            // for a user to cancel their orders after the feature is re-enabled
            // or they may be able to execute the order at an outdated price
            // depending on the order keeper
            // disabling of features should be a rare occurrence, it may be
            // preferrable to still execute the orders when the feature is re-enabled
            // instead of cancelling / freezing the orders
            // if features are not frequently disabled, the amount of front-running
            // from this should not be significant
            // based on this it may also be advisable to disable the cancelling of orders
            // if the execution of orders is disabled
            errorSelector == Errors.InvalidKeeperForFrozenOrder.selector ||
            errorSelector == Errors.UnsupportedOrderType.selector ||
            // the transaction is reverted for InvalidOrderPrices since the oracle prices
            // do not fulfill the specified trigger price
            errorSelector == Errors.InvalidOrderPrices.selector ||
            // order should not be cancelled or frozen in this case
            // otherwise malicious keepers can cancel orders before valid from time is reached
            errorSelector == Errors.OrderValidFromTimeNotReached.selector
        ) {
            ErrorUtils.revertWithCustomError(reasonBytes);
        }

        (string memory reason /* bool hasRevertMessage */, ) = ErrorUtils.getRevertMessage(reasonBytes);

        if (
            isMarketOrder ||
            errorSelector == Errors.InvalidPositionMarket.selector ||
            errorSelector == Errors.InvalidCollateralTokenForMarket.selector ||
            errorSelector == Errors.InvalidPositionSizeValues.selector
        ) {
            OrderUtils.cancelOrder(
                OrderUtils.CancelOrderParams(
                    dataStore,
                    eventEmitter,
                    multichainVault,
                    orderVault,
                    key,
                    keeper,
                    startingGas,
                    true, // isExternalCall
                    false, // isAutoCancel
                    reason,
                    reasonBytes
                )
            );

            return;
        }

        // freeze unfulfillable orders to prevent the order system from being gamed
        // an example of gaming would be if a user creates a limit order
        // with size greater than the available amount in the pool
        // the user waits for their limit price to be hit, and if price
        // moves in their favour after, they can deposit into the pool
        // to allow the order to be executed then close the order for a profit
        //
        // frozen order keepers are expected to execute orders only if the
        // latest prices match the trigger price
        //
        // a user can also call updateOrder to unfreeze an order
        OrderUtils.freezeOrder(
            dataStore,
            eventEmitter,
            multichainVault,
            orderVault,
            key,
            keeper,
            startingGas,
            reason,
            reasonBytes
        );
    }

    // @dev validate that the keeper is a frozen order keeper
    // @param keeper address of the keeper
    function _validateFrozenOrderKeeper(address keeper) internal view {
        if (!roleStore.hasRole(keeper, Role.FROZEN_ORDER_KEEPER)) {
            revert Errors.InvalidKeeperForFrozenOrder(keeper);
        }
    }
}
