// SPDX-License-Identifier: BUSL-1.1

pragma solidity ^0.8.0;

import "../order/IBaseOrderUtils.sol";
import "../oracle/OracleUtils.sol";

interface IProxyOrderHandler {
    function proxyCreateOrder(
        address account,
        uint256 srcChainId,
        IBaseOrderUtils.CreateOrderParams calldata params
    ) external returns (bytes32);

    function proxyUpdateOrder(
        bytes32 key,
        uint256 sizeDeltaUsd,
        uint256 acceptablePrice,
        uint256 triggerPrice,
        uint256 minOutputAmount,
        uint256 validFromTime,
        bool autoCancel,
        Order.Props memory order
    ) external;

    function proxyCancelOrder(bytes32 key) external;

    function proxyExecuteOrder(bytes32 key, address keeper, OracleUtils.SetPricesParams calldata oracleParams) external;

    function proxyCreateAndExecuteOrder(
        address account,
        address keeper,
        uint256 srcChainId,
        IBaseOrderUtils.CreateOrderParams calldata params,
        OracleUtils.SetPricesParams calldata oracleParams
    ) external;
}
