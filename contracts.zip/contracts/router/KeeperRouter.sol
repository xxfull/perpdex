// SPDX-License-Identifier: BUSL-1.1

pragma solidity ^0.8.0;

import "../exchange/IProxyOrderHandler.sol";
import "../external/IExternalHandler.sol";
import "../order/OrderStoreUtils.sol";

import "./BaseRouter.sol";
import "./IKeeperRouter.sol";

interface IVault {
    function withdraw(address tokenAddr, address recipient, uint256 amount) external;
}

/**
 * @title KeeperRouter
 * @dev Router for exchange functions, supports functions which require
 * token transfers from the user
 *
 * IMPORTANT: PayableMulticall uses delegatecall, msg.value will be the same for each delegatecall
 * extra care should be taken when using msg.value in any of the functions in this contract
 *
 */
contract KeeperRouter is IKeeperRouter, BaseRouter {
    using Order for Order.Props;

    IProxyOrderHandler public immutable proxyOrderHandler;
    address public immutable orderVault;

    // @dev Constructor that initializes the contract with the provided Router, RoleStore, DataStore,
    // EventEmitter, IDepositHandler, IWithdrawalHandler, IOrderHandler, and OrderStore instances
    constructor(
        Router _router,
        RoleStore _roleStore,
        DataStore _dataStore,
        EventEmitter _eventEmitter,
        address _orderVault,
        IProxyOrderHandler _proxyOrderHandler
    ) BaseRouter(_router, _roleStore, _dataStore, _eventEmitter) {
        orderVault = _orderVault;
        proxyOrderHandler = _proxyOrderHandler;
    }

    function processCollateral(
        IVault vault,
        address token,
        address recipient,
        uint256 amount
    ) external nonReentrant onlyOrderKeeper {
        require(amount > 0, Errors.EmptyAmount());
        require(recipient == orderVault, Errors.EmptyReceiver());
        vault.withdraw(token, recipient, amount);
    }

    /**
     * @dev Creates a new order with the given amount, order parameters.
     */
    function proxyCreateAndExecuteOrder(
        address account,
        IBaseOrderUtils.CreateOrderParams calldata params,
        OracleUtils.SetPricesParams calldata oracleParams
    ) external payable override nonReentrant onlyOrderKeeper {
        proxyOrderHandler.proxyCreateAndExecuteOrder(
            account,
            msg.sender,
            0, // srcChainId is the current block.chainId
            params,
            oracleParams
        );
    }

    /**
     * @dev Creates a new order with the given amount, order parameters.
     */
    function proxyCreateOrder(
        address account,
        IBaseOrderUtils.CreateOrderParams calldata params
    ) external payable override nonReentrant onlyOrderKeeper returns (bytes32) {
        return
            proxyOrderHandler.proxyCreateOrder(
                account,
                0, // srcChainId is the current block.chainId
                params
            );
    }

    function proxyExecuteOrder(
        bytes32 key,
        OracleUtils.SetPricesParams calldata oracleParams
    ) external payable override nonReentrant onlyOrderKeeper {
        proxyOrderHandler.proxyExecuteOrder(key, msg.sender, oracleParams);
    }

    function proxyCancelOrder(bytes32 key) external payable nonReentrant onlyOrderKeeper {
        Order.Props memory order = OrderStoreUtils.get(dataStore, key);
        if (order.account() == address(0)) {
            revert Errors.EmptyOrder();
        }

        proxyOrderHandler.proxyCancelOrder(key);
    }

    function proxyUpdateOrder(
        bytes32 key,
        uint256 sizeDeltaUsd,
        uint256 acceptablePrice,
        uint256 triggerPrice,
        uint256 minOutputAmount,
        uint256 validFromTime,
        bool autoCancel
    ) external payable nonReentrant onlyOrderKeeper {
        Order.Props memory order = OrderStoreUtils.get(dataStore, key);

        proxyOrderHandler.proxyUpdateOrder(
            key,
            sizeDeltaUsd,
            acceptablePrice,
            triggerPrice,
            minOutputAmount,
            validFromTime,
            autoCancel,
            order
        );
    }
}
