// SPDX-License-Identifier: BUSL-1.1

pragma solidity ^0.8.0;

import "../oracle/OracleUtils.sol";
import "../order/IBaseOrderUtils.sol";

interface IKeeperRouter {
    function proxyCreateAndExecuteOrder(
        address account,
        IBaseOrderUtils.CreateOrderParams calldata params,
        OracleUtils.SetPricesParams calldata oracleParams
    ) external payable;

    function proxyCreateOrder(
        address account,
        IBaseOrderUtils.CreateOrderParams calldata params
    ) external payable returns (bytes32);

    function proxyExecuteOrder(bytes32 key, OracleUtils.SetPricesParams calldata oracleParams) external payable;

    function proxyCancelOrder(bytes32 key) external payable;

    function proxyUpdateOrder(
        bytes32 key,
        uint256 sizeDeltaUsd,
        uint256 acceptablePrice,
        uint256 triggerPrice,
        uint256 minOutputAmount,
        uint256 validFromTime,
        bool autoCancel
    ) external payable;
}
